var size = 0;
var placement = 'point';

var style_UAL_Line_Habitat_5 = '';
