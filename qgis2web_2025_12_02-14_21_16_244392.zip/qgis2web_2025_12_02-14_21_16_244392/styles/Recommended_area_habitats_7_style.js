var size = 0;
var placement = 'point';

var style_Recommended_area_habitats_7 = '';
